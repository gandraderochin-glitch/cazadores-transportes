# Cazadores Transportes — Sitio Web

Sitio web oficial de **Cazadores Transportes** (Hunters Trucking Solutions S.A. de C.V.), basado en la identidad visual de la presentación comercial: verde bosque, crema, tipografía Bebas Neue + Poppins, y emblema del águila/escudo recreado en SVG vectorial.

## Estructura de archivos

```
/
├── index.html              → Página principal (todo el contenido del sitio)
└── assets/
    ├── estilos.css          → Todos los estilos visuales
    ├── script.js             → Interacciones (menú, animaciones, formulario)
    └── logo-emblem.svg       → Logo vectorial del águila/escudo
```

## Cómo ver el sitio en tu computadora antes de publicarlo

1. Descarga estos 4 archivos manteniendo la misma estructura de carpetas (la carpeta `assets` debe estar junto a `index.html`).
2. Haz doble clic en `index.html` — se abre directo en tu navegador. Así puedes revisar todo antes de subirlo.

## Cómo publicarlo en GitHub Pages (gratis)

1. **Crea una cuenta en GitHub** (si no tienes una) en github.com.
2. **Crea un repositorio nuevo**: dale un nombre como `cazadores-web`, márcalo como público.
3. **Sube los archivos**: en la página del repositorio, dale a "uploading an existing file" y arrastra `index.html` y la carpeta `assets` completa (o usa GitHub Desktop / git si prefieres línea de comandos).
4. **Activa GitHub Pages**: ve a Settings → Pages (menú lateral) → en "Source" elige la rama `main` y la carpeta `/ (root)` → Save.
5. Espera 1–2 minutos. GitHub te dará una URL tipo `https://tu-usuario.github.io/cazadores-web/`.
6. **(Opcional) Dominio propio**: si compras un dominio (ej. cazadorestransportes.com), en Settings → Pages agrega el dominio en "Custom domain" y configura los registros DNS que GitHub te indique (normalmente un registro CNAME apuntando a `tu-usuario.github.io`).

## Cosas que debes personalizar antes de publicar

- **Número de WhatsApp**: en `index.html` y `script.js` busca `5218119876755` (con código de país 52 + 81 + número) y confírmalo o ajústalo — actualmente usa el de la presentación.
- **Fotos reales**: si quieres reemplazar la bandera ilustrada por fotos reales de tu flota, puedes agregar imágenes a `assets/` y ajustar el HTML de `.hero-visual`.
- **Google Fonts**: el sitio carga Bebas Neue y Poppins desde Google Fonts vía internet — esto es automático y no requiere que instales nada, solo necesita que el visitante tenga conexión (algo estándar).

## Notas de diseño

- Los colores (`#33422A` verde oscuro, `#E8E6D9` crema, `#5C7A3F` olivo, `#5B4A30` bronce) fueron extraídos directamente de tu presentación comercial.
- El logo es una reconstrucción vectorial (SVG) fiel al emblema original del águila/escudo de la bandera, para que se vea nítido en cualquier tamaño y pantalla (a diferencia de una foto/JPG que se pixelea).
- El mapa de "Cobertura Nacional" es una representación geométrica estilizada de México (no un mapa cartográfico exacto), consistente con el estilo angular del logo.
